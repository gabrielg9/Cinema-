#include<iostream>
#include<string>
#include"Akcja.h"
#include"Film.h"

using namespace std;

Akcja::Akcja()
{

}

Akcja::~Akcja()
{

}

double Akcja::cenaZKodemRabatowym()
{
	int tablicaKodow[10] = { 111, 222, 333, 444, 555, 666, 777, 888, 999, 000 };
	cout << endl << "Podaj 3-cyfrowy kod rabatowy: ";
	int kod;
	cin >> kod;
	bool zamiana = false;
	for (int i = 0; i < 10; i++)
	{
		if (tablicaKodow[i] == kod)
		{
			zamiana = true;
			break;
		}
		else
		{
			zamiana = false;
		}
	}
	if (zamiana == 1)
	{
		cena *= 0.7;
		cout << endl << "Kod poprawny, cena zosta�a obni�ona o 30% i teraz wynosi ona " << cena << " z�otych" << endl;
		return cena;
	}
	else
	{
		cout << endl << "Kod nieprawid�owy - cena wynosi " << cena << " z�otych" << endl;
		return cena;
	}
}