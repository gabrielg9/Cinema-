#include<iostream>
#include"Film.h"
using namespace std;

Film::Film()
{
	
}

Film::~Film()
{

}

double Film::cenaZKodemRabatowym()
{
	return 0;
}